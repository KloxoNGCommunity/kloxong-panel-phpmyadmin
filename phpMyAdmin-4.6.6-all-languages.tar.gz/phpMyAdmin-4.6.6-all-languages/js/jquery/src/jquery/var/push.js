define([
	"./arr"
], function( arr ) {
	return arr.push;
});
